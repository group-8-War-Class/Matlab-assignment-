classdef NewtonRaphson < NumericalSolver
  methods
        function res = execute(obj, inputs)
            % Extract your inputs from the array passed by the app
            x0 = inputs(1);      % Initial guess
            tol = inputs(2);     % Tolerance or limit
            maxIter = inputs(3); % Step sizes / max iterations
           
            % Define your function and its derivative (example: x^2 - 4 = 0)
            f = @(x) x.^2 - 4;
            df = @(x) 2*x;
           
            % Newton-Raphson loop
            x = x0;
            for i = 1:maxIter
                x_new = x - f(x)/df(x);
                if abs(x_new - x) < tol
                    x = x_new;
                    break;
                end
                x = x_new;
            end
           
            % Assign the final calculated root directly to 'res'
            res = x;
        end
    end
end