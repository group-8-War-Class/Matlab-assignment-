classdef (Abstract) NumericalSolver
    properties
        MethodName
    end
    methods (Abstract)
        result = execute(obj, inputs);
    end
end

