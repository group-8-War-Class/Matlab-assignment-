% Group different solver objects into a single array (Over-arraying)
solvers = {NewtonRaphson(), TrapezoidalRule()};

% Run a loop to execute each method polymorphically
for i = 1:length(solvers)
    disp(solvers{i}.MethodName);
    % Pass respective parameters for testing
    if i == 1
        res = solvers{i}.execute([1.0, 1e-5, 100]); % Newton-Raphson inputs
    else
        res = solvers{i}.execute([0, 2, 10]);       % Trapezoidal inputs
    end
    disp(['Result: ', num2str(res)]);
end