classdef TrapezoidalRule < NumericalSolver
    methods
        function res = execute(obj, inputs)
            % 1. Extract inputs from the app's input array [a, b, n]
            a = inputs(1);      % Lower limit
            b = inputs(2);      % Upper limit
            n = inputs(3);      % Number of subintervals (step sizes)
           
            % 2. Define the function to integrate (change this to your desired function)
            f = @(x) x.^2;
           
            % 3. Implement the Trapezoidal Rule calculation
            h = (b - a) / n;
            x = linspace(a, b, n + 1);
            y = f(x);
           
            % Composite trapezoidal rule formula
            integralValue = (h / 2) * (y(1) + 2 * sum(y(2:end-1)) + y(end));
           
            % 4. Assign the final calculated integral directly to 'res'
            res = integralValue;
        end
    end
end